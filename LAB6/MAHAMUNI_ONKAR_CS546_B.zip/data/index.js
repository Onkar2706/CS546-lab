// This file should import both data files and export them as shown in the lecture code

import prodMethods from './products.js';
import reviewMethods from './reviews.js';

export const pm = prodMethods;
export const rm = reviewMethods;